# Data-Dictionary

Data dictionary service.

# License

Copyright (c) 2022 Milko Škofič

License: Apache 2